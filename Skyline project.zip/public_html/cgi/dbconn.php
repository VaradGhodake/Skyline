<?php

$conn = mysqli_connect('mysql.hostinger.in', 'u645308283_root', 'darkhorse', 'u645308283_demo');
$cookie_name = "loggedin";

if(!$conn){
  die("Error connecting to the database: ".mysqli_connect_error());
}
