<?php
$cookie_name = "loggedin";
if(isset($_COOKIE[$cookie_name])){
      header("Location: main.php");}
 ?>

<html>
      <head>
          <title>Login</title>
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
          <link href='https://fonts.googleapis.com/css?family=Satisfy' rel='stylesheet' type='text/css'>
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
          <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
          <link rel="stylesheet" href="/css/style.css">
      </head>
      <body background="/static/background.jpg">
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">

                <!-- Header -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#topNavBar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href = "/index.html"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;&nbsp;Skyline</a>
                </div>

                <!--right side-->
                <ul class="nav navbar-nav navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="login"><a href="/login.html"><span class="glyphicon glyphicon-log-in" aria-hidden="true"></span>&nbsp; Log-in</a></li>
                        <li class="register"><a href="/register.html"><span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span>&nbsp; Sign-up</a></li>
                    </ul>
                  </div>
              </nav>
              <br><br><br>
          <div style="margin-left:auto; margin-right:auto; width:40%; text-align:center;">
                <h2>Login</h2>
                <br>
                <?php
                include "dbconn.php";

                $name = $_POST['name'];
                $pass = $_POST['pass'];

                $sql = "SELECT * FROM user WHERE usr='$name' AND pwd = '$pass'";
                $result = $conn -> query($sql);

                if(!$row = $result -> fetch_assoc()){
                    echo "Username and password do not match";
                }else{
                    $cookie_value = $name;
                    setcookie($cookie_name, $cookie_value, time() + (86400), "/");
                    header("Location: main.php");
                }
                ?>
                <br><br>
                <form action="login.php" method = "POST">
                    <div align = "center">
                          <input type = "text" name="name" placeholder="Username"/>
                          <br><br>
                          <input type = "password" name="pass" placeholder="Password"/>
                          <br><br>
                          <input type="submit" value="submit" />
                          <br>
                          <h5>Not a user?<a href="/register.html"> Sign-up</a><h5>
                    </div>
                  </form>
          </div>

      </body>
</html>
