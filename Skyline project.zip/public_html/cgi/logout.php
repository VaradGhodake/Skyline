<?php
$cookie_name = "loggedin";
$cookie_value = $_COOKIE[$cookie_name];
$conn = mysqli_connect('mysql.hostinger.in', 'u645308283_root', 'darkhorse', 'u645308283_demo');
mail('varadghodake@gmail.com','Logout','You have been logged out successfully',"From:myphpapp@myphpapp.esy.es");
if(!$conn){
  die("Error connecting to the database: ".mysqli_connect_error());}
$sql = "UPDATE user SET active = 0 WHERE usr = '$cookie_value'";
if (mysqli_query($conn, $sql)) {
  echo "Done!";
}
setcookie($cookie_name, null, -1, "/");
header("Location: outro.php");
 ?>
