<html>
      <head>
          <title>Skyline</title>
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
          <link href='https://fonts.googleapis.com/css?family=Satisfy' rel='stylesheet' type='text/css'>
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
          <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
          <link rel="stylesheet" href="css/style.css">
      </head>
      <body background="/static/background.jpg">
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">

                <!-- Header -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#topNavBar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href = "main.php"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;&nbsp;Skyline</a>
                </div>

                <!--right side-->
                <ul class="nav navbar-nav navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="logout"><a href="logout.php"><span class="glyphicon glyphicon-off" aria-hidden="true"></span>&nbsp; Log-out</a></li>
                    </ul>
                  </div>
              </nav>
              <?php
                $cookie_name = "loggedin";
                if(isset($_COOKIE[$cookie_name])){
                    $cookie_value = $_COOKIE[$cookie_name];
                    echo '<h2>'."Hello, ".$cookie_value."!".'</h2>';
                }else{
                  header("Location: /login.html");
                }
               ?>

               <div style="margin-left:auto; margin-right:auto; width:30%; text-align:center;">
                     <br>
                        <h2 style="color : 069";>Active users right now</h2>
                        <br>
                         <div align = "center">

                              <?php

                              $conn = mysqli_connect('mysql.hostinger.in', 'u645308283_root', 'darkhorse', 'u645308283_demo');


                              if(!$conn){
                                die("Error connecting to the database: ".mysqli_connect_error());}

                              $sql = "UPDATE user SET active = 1 WHERE usr = '$cookie_value'";
                                if (mysqli_query($conn, $sql)) {
                                  $active = "SELECT * FROM user WHERE active= 1";
                                  $result = $conn -> query($active);
                                  while($row = $result -> fetch_assoc()){
                                    echo '<h3>'.'<span class="glyphicon glyphicon-user" aria-hidden="true"></span>'.'&nbsp;'.$row['usr'].'</h3>';

                                 }
                               }
                              ?>

                         </div>

               </div>

            </body>
</html>
