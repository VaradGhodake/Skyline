<html>
      <head>
          <title>Skyline</title>
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
          <link href='https://fonts.googleapis.com/css?family=Satisfy' rel='stylesheet' type='text/css'>
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
          <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
          <link rel="stylesheet" href="css/style.css">
      </head>
      <body>
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">

                <!-- Header -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#topNavBar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href = "/index.html"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;&nbsp;Skyline</a>
                </div>

                <!--right side-->
                <ul class="nav navbar-nav navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="logout"><a href="logout.php"><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>&nbsp; Contact-Us</a></li>
                    </ul>
                  </div>
              </nav>
              <br><br><br>
              <div align = "center">
                    <h1>Thank you for using our services</h1><br><br><br>
              </div>
     </body>
</html>
