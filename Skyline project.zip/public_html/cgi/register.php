<?php
  $cookie_name = "loggedin";
  if(isset($_COOKIE[$cookie_name])){
      header("Location: main.php");}

?>


<html>
      <head>
          <title>Register</title>
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
          <link href='https://fonts.googleapis.com/css?family=Satisfy' rel='stylesheet' type='text/css'>
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
          <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
          <link rel="stylesheet" href="/css/style.css">
      </head>
      <body background="/static/background.jpg">
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">

                <!-- Header -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#topNavBar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href = "/index.html"><span class="glyphicon glyphicon-send" aria-hidden="true"></span>&nbsp;&nbsp;Skyline</a>
                </div>

                <!--right side-->
                <ul class="nav navbar-nav navbar-right">
                    <ul class="nav navbar-nav">
                        <li class="login"><a href="/login.html"><span class="glyphicon glyphicon-log-in" aria-hidden="true"></span>&nbsp; Log-in</a></li>
                        <li class="register"><a href="/register.html"><span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span>&nbsp; Sign-up</a></li>
                    </ul>
                  </div>
              </nav>
              <br><br><br>
          <div style="margin-left:auto; margin-right:auto; width:40%; text-align:center;">
                <h2>Sign-up</h2>
                <br>
                <?php
                include "dbconn.php";

                $name = $_POST['name'];
                $pass = $_POST['pass'];
                $mail = $_POST['email'];
                $query = mysqli_query($conn, "SELECT * FROM user WHERE usr = '$name'");
                if(mysqli_num_rows($query) != 0)
                {
                    echo "Username already exists";
                }
                else if(empty($name) === true || empty($pass) === true || empty($mail) === true)
                {
                    echo "Cannot have empty fields";
                }else if (!filter_var($mail, FILTER_VALIDATE_EMAIL))
                {
                    echo "Invalid email format";
                }else
                {
                $sql = "INSERT INTO user (usr, pwd, mail) VALUES ('$name', '$pass', '$mail') ";
                $result = $conn -> query($sql);
                $cookie_value = $name;
                setcookie($cookie_name, $cookie_value, time() + (86400), "/");
                header("Location: main.php");
                }
                ?>
                <br><br>
                <form action="register.php" method = "POST">
                    <div align = "center">
                          <input type = "text" name="name" placeholder="Username"/>
                          <br><br>
                          <input type = "password" name="pass" placeholder="Password"/>
                          <br><br>
                          <input type = "text" name="email" placeholder="E-Mail Id"/>
                          <br><br>
                          <input type="submit" value="submit" />
                          <br>

                          <h5>Already a user?<a href="/login.html"> log-in</a><h5>
                    </div>
                  </form>
          </div>

      </body>
</html>
